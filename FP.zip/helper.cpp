#include <iostream>
#include "helper.h"

using namespace std;

int inputSV(int maximum, int& singularValue){
  while(cout << "Singular Values: "){
  cin >> singularValue;

  //handling the input
  if(!cin.fail()) {
        // check if number was valid or not
        if(singularValue < 0 || singularValue > maximum || cin.peek() == '.') {
            cout << "Please enter a valid integer" << endl;

            //if the user eneterd a floating point number, get ride of it
            if(cin.peek() == '.'){
              cin.clear();
              char badChar = ' ';
              do { badChar = cin.get(); } while(badChar != '\n');
            }
        } else {
            return singularValue;
        }
    } else {
        cout << "Input failed, please enter an integer." << endl;
        cin.clear();
        char badChar = ' ';
        do { badChar = cin.get(); } while(badChar != '\n');
    }
  }
  //compiler got angry for not having a return statement
  //this should not get called
  cout << "escaped somehow" << endl;
  return 0;
}