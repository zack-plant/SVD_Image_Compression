/*
 * CSCI 200: Final Project - Single Value Decomposition of Image Matrixes
 *
 * Author: Zack Disler
 *
 * Using SFML and Eigen to perform Single Value Decomposition of an input image
 * and output the result.


Sources: https://stackoverflow.com/questions/16596876/gcc-equivalent-of-mss-bigobj
         https://caiorss.github.io/C-Cpp-Notes/compiler-flags-options.html#org68aa48b
         https://stackoverflow.com/questions/44456197/access-to-u-s-v-with-eigen-svd
         https://eigen.tuxfamily.org/dox/classEigen_1_1SVDBase.html
         https://blog.demofox.org/2022/07/12/calculating-svd-and-pca-in-c/
         https://www.sfml-dev.org/documentation/2.6.1/classsf_1_1Image.php
*/

#include "Eigen/Dense"
#include "Eigen/Core"
#include <iostream>
#include "Eigen/SVD"
#include <SFML/Graphics.hpp>
#include <SFML/Graphics/Image.hpp>
#include <string>
#include <iomanip>
#include "ImageProcessor.h"
#include "helper.h"


using namespace std;
using namespace Eigen;
using namespace sf;

ImageProcessor image = ImageProcessor();


int main(){

  cout << setfill('%') << setw(20) << "" << endl;
  cout << setfill('%') << setw(20) << "" << endl << endl;

  cout << "***Introduction***" << endl;
  cout << "Welcome to the Single Value Decomposition image maker! Single value decomposition is a nifty tool from" << endl;
  cout << "linear algebra that allows any set of coefficients to be approximated by a smaller set of the most" << endl;
  cout << "representitive values. It does this by breaking up the data into individual groups, each with a weight" << endl;
  cout << "(called a \"Singular Value\"). By choosing only the groups with the highest weights, we get a pretty good" << endl;
  cout << "approximations of the data set using a much smaller amount of data. This behaviour is most obvious in" << endl;
  cout << "image compression! By taking an image and slowly increasing the number of singular values (starting from" << endl;
  cout << "the highest weight), you can begin to resolve an image." << endl;
  cout << endl;
  cout << "Note: The size of the output image is the same size as the input one. SVD doesnt make the image literally" << endl;
  cout << "smaller, rather, it allows the image to be constructed from less actual bytes. Each image could be stored" << endl;
  cout << "in a much smaller format, then reconstructed when needed. Additionally, at a certain point the matrixes" << endl;
  cout << "used to store the SVD become bigger than the actual image so it's best for low-value approximations." << endl;
  cout << endl;
  cout << "***Instructions***" << endl;
  cout << "Try choosing a mystery image. See how many singular values it takes for you to recognize it! You can also" << endl;
  cout << "load an image of your own by including it in the root directory or entering it's path. Make sure to" << endl;
  cout << "include the filetype in the name! "  << endl << endl;

  cout << setfill('%') << setw(20) << "" << endl;
  cout << setfill('%') << setw(20) << "" << endl;

  short inputLocation = 0;
  while(true) {
      cout << "What image do you want to process?" << endl;
      cout << "\t1 - Mystery 1" << endl;
      cout << "\t2 - Mystery 2" << endl;
      cout << "\t3 - Mystery 3" << endl;
      cout << "\t4 - Mystery 4" << endl;
      cout << "\t5 - Enter other filename" << endl;
      cin >> inputLocation;

      // make sure we got a number
      if(!cin.fail()) {
          // check if number was valid or not
          if(inputLocation < 0 || inputLocation > 5) {
              cout << "Please enter a valid choice" << endl;
          } else {
              break;
          }
      } else {
          cin.clear();
          char badChar = ' ';
          do { badChar = cin.get(); } while(badChar != '\n');
      }
  }
  string filename = "";
  switch(inputLocation) {
      case 1: filename = "input/mystery1.jpg";    break;
      case 2: filename = "input/mystery2.jpg";    break;
      case 3: filename = "input/mystery3.jpg";    break;
      case 4: filename = "input/mystery4.jpg";    break;
      case 5:
          cout << "Enter image to process: ";
          cin >> filename;
          break;
  }


  // open file for parsing, handling failiure
  if(!image.loadFromFile(filename)) {
      cerr << "Could not open file \"" << filename << "\" for reading.  Shutting down..." << endl;
      return -1;
  }

  //get the size of the image
  int cols = image.getSize().x;
  int rows = image.getSize().y;
  int maximum;

  //the maximum value is equal to the smallest dimention
  //from the SVD we know that the number of singular values is going to be equal to the smallest dimension
  if (cols >= rows){
      maximum = rows;
  } else { maximum = cols;}

  cout << "Choose a number of singular values between 0 and " << maximum << endl;
  cout << "Close the image to choose another singular value or save the image." << endl;





  // create an event object once to store future events
  Event event;


  //get the first amount of singular values
  //inputSV has exception handling
  int singularValues;
  inputSV(maximum, singularValues);

  //create sf objects to use in image output
  //need to load sf::image into a sf::texture, than create a sf::sprite with the texture to display it
  sf::Texture texture; 
  sf::Sprite sprite;

  //create a scaling value for the sprite, based on the image size
  int scale;
  if( rows > cols){
    scale = 800/rows; //if portrait, set height to 800 pixels
  } else {
    scale = 800/cols; //if landscape, set width to 800 pixels
  }

  RenderWindow window;
  do{

    //created the drawable image
    image.SVD(singularValues);

    //pass the texture a pointer to the processed image
    if(!texture.loadFromImage(*image.getProcessedImagePtr())){
      break;
    }
    //pass the sprite the texture
    sprite.setTexture(texture); 
    
    //set the scale of the sprite
    sprite.setScale(scale, scale);

    //display loop
    window.create(VideoMode(cols * scale, rows * scale), "SVD" );
    while( window.isOpen() ) {
        // clear any existing contents
        window.clear(Color::Black);

        /////////////////////////////////////
        // BEGIN DRAWING HERE

        window.draw(sprite);

        //  END  DRAWING HERE

        /////////////////////////////////////


        // display the current contents of the window
        window.display();

        /////////////////////////////////////
        // BEGIN EVENT HANDLING HERE
        // check if any events happened since the last time checked
        while( window.pollEvent(event) ) {
            // if event type corresponds to pressing window X
            if(event.type == Event::Closed) {
                // tell the window to close
                window.close();
            }
            // check addition event types to handle additional events
        }
        //  END  EVENT HANDLING HERE
        /////////////////////////////////////
      }
    cout << "Data used: " << ((rows * singularValues + cols * singularValues + singularValues) * 1.0 / (rows * cols)) * 100<< "%" << endl;

    cout << "Enter 0 to close and save, or another singular value (less than " << maximum << ")" << endl;
    //at the end of every loop, get another singular value
  } while (inputSV(maximum, singularValues));

cout << "Image saved to Output.jpg" << endl;
//save the image at the end of the program
image.saveToFile("Output.jpg");
  
return 1;
}