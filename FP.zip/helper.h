#ifndef HELPER_H
#define HELPER_H

/**
 * @brief a little helper function that gets a positive integer less than the max from the
 *        user and sets singularValues to it
 * 
 * @return returns the input value. This is just for use in the while loop
 *         so that it ends when 0 is entered.
 */
int inputSV(int max, int& singularValues);

#endif