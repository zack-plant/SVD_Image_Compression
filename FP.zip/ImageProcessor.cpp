# include "ImageProcessor.h"

using namespace Eigen;

  //in the initilizer list, use the image initializer first
  ImageProcessor::ImageProcessor(): Image(){
    ;
  }

  //takes a filename as input
  ImageProcessor::ImageProcessor(const std::string & filename): Image(){
    this->ImageProcessor::loadFromFile(filename);
  }

  //a private function that takes all the pixel data and inserts it into the RGBA matrixes
  //used in loadFromFile and SVD to get the original RGBA values for every call of SVD
  void ImageProcessor::mPopulateMatrixes(){
    //pointer to the array of pixels in the image, where each is RGBA
    const sf::Uint8 * pixels = this->getPixelsPtr();

    //variables for the size of the image
    int cols = this->getSize().x;
    int rows = this->getSize().y;

    //take values from pixelPtrs and populate color matrixes with value as float (for SVD)
    for(int i = 0; i < rows*cols; i++){
      mMatrixR(i) = (float)pixels[i*4]; //first value is red
      mMatrixG(i) = (float)pixels[i*4 + 1]; //second value is green
      mMatrixB(i) = (float)pixels[i*4 + 2]; //third value is blue
      mMatrixA(i) = (float)pixels[i*4 + 3]; //fourth value is alpha
    }
  }

  //used to load an image from file
  //primarily initializes member datastructures
  bool ImageProcessor::loadFromFile(const std::string & filename){
    if (this->Image::loadFromFile(filename)) {

    //variables for the size of the image
    int cols = this->getSize().x;
    int rows = this->getSize().y;

    //resize each color matrix to hold the individual color info
    mMatrixR.resize(rows, cols);
    mMatrixG.resize(rows, cols);
    mMatrixB.resize(rows, cols);
    mMatrixA.resize(rows, cols);

    //puts RGBA values into matrixes
    mPopulateMatrixes();
    
    return true;
    } else {
    std::cout << "Failed to load image." << std::endl;
    return false;
    }
  }

  //just a helper function
  //takes floats from matrixes and turns them into Uint8 values for sfml pixels
  sf::Uint8 converter(const float value){
    if(value >= 0.0 && value <= 255.0){
      return sf::Uint8(value);
    } else if (value < 0.0){
      return sf::Uint8(0);
    } else {
      return sf::Uint8(255);
    }
  }

  //
  void ImageProcessor::SVD(const int singularNumb){
    //repopulate matrix to get original image to process
    mPopulateMatrixes();

    //perform svd on individual RGBA matrixes
    _singleSVD(mMatrixR, singularNumb);
    _singleSVD(mMatrixG, singularNumb);
    _singleSVD(mMatrixB, singularNumb);
    _singleSVD(mMatrixA, singularNumb);

    int cols = this->getSize().x;
    int rows = this->getSize().y;

    //take all of the processed RGBA matrixes and put them in this pixel matrix
    sf::Uint8 * pixels = new sf::Uint8[rows * cols * 4];

    //walks over the list by fours, putting the RGBA pixels in that order in each group of four
    for(int i = 0; i < rows * cols; i++){
      pixels[i*4] = converter(mMatrixR(i));
      pixels[i*4 + 1] = converter(mMatrixG(i));
      pixels[i*4 + 2] = converter(mMatrixB(i));
      pixels[i*4 + 3] = converter(mMatrixA(i));
    }

    processedImage.create(cols, rows, pixels);
  }

  sf::Image* ImageProcessor::getProcessedImagePtr(){
    return &processedImage;
  }

  void ImageProcessor::saveToFile(const std::string &filename){
    processedImage.saveToFile(filename);
  }
