#include "ImageProcessor.h"

using namespace Eigen;  

//put this bad boy in another implementation file because the object file was too big
//I had to turn on the compiler optimization still
void ImageProcessor::_singleSVD(MatrixXd_r& target, int singularNum){
  //creates an single value decomposition object using the eigen library
  //basically, it computes the U, V, and singular value matrixes
  BDCSVD<MatrixXd_r> svd( target, ComputeThinU | ComputeThinV);
  
  //mathematical work to get low rank approximations from SVD object
  target = svd.matrixU().leftCols(singularNum) //the first singularNum cols of the U matrix
          * svd.singularValues().head(singularNum).asDiagonal() //the first singularNum cols of singular values, as a square matrix
          * svd.matrixV().transpose().topRows(singularNum); //the transpose of V, taking the top singularNum rows
}
