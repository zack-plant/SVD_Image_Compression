#ifndef IMAGEPROCESSOR
#define IMAGEPROCESSOR

#include <SFML/Graphics.hpp>
#include <SFML/Graphics/Image.hpp>
#include "Eigen/Core"
#include "Eigen/SVD"
#include "Eigen/Dense"
#include <iostream>


class ImageProcessor: public sf::Image {
  public:

  /**
   * @brief Construct a new Image Processor object
   * 
   */
  ImageProcessor();

  /**
   * @brief Construct a new Image Processor object while also loading the image
   * 
   * @param filename 
   */
  ImageProcessor(const std::string &filename);

  /**
   * @brief loads in an image from a file and files in the color channel matrixs of ImageProcessor
   * 
   * @param filename 
   * @return true 
   * @return false 
   */
  bool loadFromFile(const std::string &filename);

  /**
   * @brief use the Eigen library to perform an SVD, generating the processedImage
   * 
   * @param eigenNumber, the number of singluar values to be used (the quality of the image)
   */
  void SVD(const int eigenNumber);

  /**
   * @brief saves processedImage to an output file
   * 
   * @param filename 
   */
  void saveToFile(const std::string &filename);

  /**
   * @brief Get the Processed Image Ptr object
   * 
   * @return sf::Image* 
   */
  sf::Image* getProcessedImagePtr();

  private:
  //define my own rowmajor matrix type so that the matrixes play well with the rowmajor sf::image array
  typedef Eigen::Matrix<float, Eigen::Dynamic, Eigen::Dynamic, Eigen::RowMajor> MatrixXd_r;

  /**
   * @brief performs an svd on the argument matrix with the given number of singular values and sets matrix equal to the svd
   * 
   */
  void _singleSVD(MatrixXd_r&, int);


  sf::Image processedImage;
  
  protected:
  MatrixXd_r mMatrixR;
  MatrixXd_r mMatrixG;
  MatrixXd_r mMatrixB;
  MatrixXd_r mMatrixA;
  
  /**
   * @brief populates the RGBA matrixes from the image object
   * 
   */
  void mPopulateMatrixes();

};


#endif